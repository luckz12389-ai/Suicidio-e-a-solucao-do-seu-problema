# 🛡️ WEB ADMINS

**The official administrative website of the server**

Site oficial de administração para servidores Discord com **login real via Discord OAuth2**.

---

## ⚡ Deploy rápido no Netlify + Discord (passo a passo)

### 1. Criar a aplicação no Discord

1. Acesse → [Discord Developer Portal](https://discord.com/developers/applications)
2. Clique em **New Application** e dê um nome (ex: `WEB ADMINS`)
3. Vá em **OAuth2** → copie o **Client ID**
4. Clique em **Reset Secret** e copie o **Client Secret** (guarde bem)
5. Em **Redirects** adicione exatamente estas URLs (troque pelo seu domínio depois do deploy):

```
https://SEU-SITE.netlify.app/.netlify/functions/auth-callback
http://localhost:8888/.netlify/functions/auth-callback
```

6. Vá na aba **Bot** → **Add Bot**
7. Ative a opção **Server Members Intent** (obrigatório)
8. Copie o **Bot Token**
9. Convide o bot para o seu servidor com a permissão de ver membros (ou use o gerador de convite com `bot` + `applications.commands` + permissão de membros)

### 2. Pegar os IDs necessários

- **Guild ID** (ID do servidor): ative o Modo Desenvolvedor no Discord → clique com botão direito no servidor → Copiar ID
- **Admin Role ID**: clique com botão direito no cargo de administrador → Copiar ID  
  (pode colocar vários separados por vírgula)

### 3. Fazer o deploy no Netlify

1. Compacte a pasta `web-admins` ou suba para um repositório GitHub
2. No [Netlify](https://app.netlify.com) → **Add new site** → Import from Git ou arraste o ZIP
3. Configurações de build:
   - **Build command**: (deixe vazio)
   - **Publish directory**: `.`
   - **Functions directory**: `netlify/functions` (já está no `netlify.toml`)

### 4. Configurar as variáveis de ambiente

No Netlify vá em **Site configuration → Environment variables** e adicione:

| Nome | Valor | Obrigatório |
|------|-------|-------------|
| `DISCORD_CLIENT_ID` | Client ID da aplicação | ✅ |
| `DISCORD_CLIENT_SECRET` | Client Secret | ✅ |
| `DISCORD_BOT_TOKEN` | Token do bot | ✅ (para verificar cargos) |
| `DISCORD_GUILD_ID` | ID do seu servidor | ✅ |
| `DISCORD_ADMIN_ROLE_IDS` | ID do cargo admin (ou vários separados por vírgula) | ✅ |
| `JWT_SECRET` | Uma string longa e aleatória (ex: gere em https://generate-secret.vercel.app/32) | ✅ |

Depois de salvar as variáveis, faça um **Trigger deploy** (Deploys → Trigger deploy → Deploy site).

### 5. Atualizar o Redirect URI

Depois que o site estiver online, volte no Discord Developer Portal e coloque a URL real:

```
https://seu-site-legal.netlify.app/.netlify/functions/auth-callback
```

---

## Como funciona o login

1. Usuário clica em **Entrar com Discord**
2. É redirecionado para `/.netlify/functions/auth-login`
3. A function manda para o Discord OAuth
4. Discord volta para `/.netlify/functions/auth-callback` com o `code`
5. A function troca o code por access_token, busca o usuário e os cargos dele no servidor (usando o Bot Token)
6. Se o usuário tiver algum cargo listado em `DISCORD_ADMIN_ROLE_IDS` → `isAdmin = true`
7. Gera um JWT e redireciona para o dashboard com o token
8. O frontend salva o token e mostra a área secreta somente se `isAdmin === true`

---

## Estrutura

```
web-admins/
├── index.html                 # Login
├── dashboard.html             # Painel
├── logo.gif
├── netlify.toml
├── js/
│   ├── auth.js                # Lógica de sessão + OAuth
│   ├── data.js                # Dados (anúncios, cartas, etc)
│   └── dashboard.js           # Interface do painel
└── netlify/functions/
    ├── auth-login.js          # Inicia OAuth
    ├── auth-callback.js       # Recebe code, gera JWT
    └── auth-me.js             # Valida JWT
```

---

## Funcionalidades

### Todos os membros logados
- Anúncios
- Regras & Updates
- Notas de Bots
- Cartas & Mensagens privadas/oficiais
- Notícias

### Área Secreta (só quem tem o cargo de Admin)
- Logins & Acessos
- Atividades do Site
- Criar Anúncios
- Enviar Cartas
- Ver informações da própria conta + cargos

---

## Dicas importantes

- O **Server Members Intent** precisa estar ativado no bot, senão os cargos não vêm.
- O bot precisa estar **dentro do servidor**.
- `DISCORD_ADMIN_ROLE_IDS` pode ter vários IDs: `123456789,987654321`
- O JWT dura 7 dias (pode mudar no código da function `auth-callback.js`)
- Dados de anúncios/cartas ainda usam `localStorage` (por usuário). Depois você pode migrar para Supabase/Planetscale se quiser dados compartilhados.

---

## Testando localmente (opcional)

```bash
npm install -g netlify-cli
netlify login
netlify dev
```

O Netlify Dev sobe as functions em `http://localhost:8888` e você pode testar o OAuth de verdade (desde que tenha colocado o redirect `http://localhost:8888/...` no Discord).

---

Feito com ❤️ para a comunidade.
