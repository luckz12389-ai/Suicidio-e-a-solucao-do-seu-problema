// WEB ADMINS - Authentication (Discord OAuth2 real)

const AUTH_KEY = 'wa_user';
const TOKEN_KEY = 'wa_token';

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function getUser() {
  const raw = localStorage.getItem(AUTH_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setSession(user, token) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(user));
  localStorage.setItem(TOKEN_KEY, token);
}

function clearSession() {
  localStorage.removeItem(AUTH_KEY);
  localStorage.removeItem(TOKEN_KEY);
}

function isLoggedIn() {
  return !!getToken() && !!getUser();
}

function isAdmin() {
  const user = getUser();
  return !!(user && user.isAdmin);
}

function logout() {
  clearSession();
  window.location.href = 'index.html';
}

// Called on dashboard load: picks token from URL hash if present
function handleAuthCallback() {
  const hash = window.location.hash;
  if (hash && hash.startsWith('#token=')) {
    const token = decodeURIComponent(hash.slice(7));
    // Clean the hash from URL
    history.replaceState(null, '', window.location.pathname + window.location.search);

    // Decode payload (without verification – verification happens on the server if needed)
    try {
      const payloadB64 = token.split('.')[1];
      const payload = JSON.parse(atob(payloadB64.replace(/-/g, '+').replace(/_/g, '/')));
      setSession(payload, token);
      return true;
    } catch (e) {
      console.error('Failed to parse token', e);
      clearSession();
      return false;
    }
  }
  return false;
}

// Start Discord login
function startLogin() {
  // Redirect to Netlify Function that starts OAuth
  window.location.href = '/.netlify/functions/auth-login';
}

// Optional: validate token with backend
async function validateSession() {
  const token = getToken();
  if (!token) return false;

  try {
    const res = await fetch('/.netlify/functions/auth-me', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) {
      clearSession();
      return false;
    }
    const user = await res.json();
    setSession(user, token); // refresh local data
    return true;
  } catch {
    // Offline or function not available – keep local session
    return !!getUser();
  }
}

// Activity logger (still local for demo purposes)
function logActivity(type, message) {
  const logs = JSON.parse(localStorage.getItem('wa_activity') || '[]');
  logs.unshift({
    id: Date.now(),
    type,
    message,
    user: getUser()?.username || getUser()?.global_name || 'Sistema',
    timestamp: new Date().toISOString()
  });
  if (logs.length > 100) logs.length = 100;
  localStorage.setItem('wa_activity', JSON.stringify(logs));
}

function getActivities() {
  return JSON.parse(localStorage.getItem('wa_activity') || '[]');
}

function logLogin(user) {
  const history = JSON.parse(localStorage.getItem('wa_logins') || '[]');
  history.unshift({
    id: Date.now(),
    userId: user.id,
    username: user.username || user.global_name,
    avatar: user.avatar,
    ip: '—',
    userAgent: navigator.userAgent.substring(0, 80),
    timestamp: new Date().toISOString(),
    isAdmin: !!user.isAdmin
  });
  if (history.length > 50) history.length = 50;
  localStorage.setItem('wa_logins', JSON.stringify(history));
}

function getLogins() {
  return JSON.parse(localStorage.getItem('wa_logins') || '[]');
}

window.WAAuth = {
  getUser,
  getToken,
  setSession,
  clearSession,
  isLoggedIn,
  isAdmin,
  logout,
  handleAuthCallback,
  startLogin,
  validateSession,
  logActivity,
  getActivities,
  logLogin,
  getLogins
};
