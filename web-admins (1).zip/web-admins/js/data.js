// WEB ADMINS - Mock Data & Storage

const STORAGE_KEYS = {
  anuncios: 'wa_anuncios',
  regras: 'wa_regras',
  bots: 'wa_bots',
  cartas: 'wa_cartas',
  noticias: 'wa_noticias',
  permissoes: 'wa_permissoes'
};

// Seed data
const SEED = {
  anuncios: [
    {
      id: 1,
      title: 'Bem-vindos ao novo painel WEB ADMINS!',
      content: 'Este é o site oficial administrativo do servidor. Aqui você receberá anúncios importantes, atualizações de regras, notas de bots e mensagens privadas (cartas). Mantenha-se sempre atualizado!',
      author: 'AdminMaster',
      authorId: '1001',
      createdAt: '2026-11-01T10:00:00Z',
      important: true,
      pinned: true
    },
    {
      id: 2,
      title: 'Evento de fim de semana',
      content: 'Neste sábado teremos um evento especial de community games a partir das 20h. Premiações em role exclusiva e badges. Participe!',
      author: 'ModeradorX',
      authorId: '1003',
      createdAt: '2026-11-04T15:30:00Z',
      important: false,
      pinned: false
    },
    {
      id: 3,
      title: 'Manutenção programada',
      content: 'No domingo das 03h às 05h (horário de Brasília) o bot principal ficará offline para atualizações de segurança. Avisaremos quando voltar.',
      author: 'AdminMaster',
      authorId: '1001',
      createdAt: '2026-11-05T09:00:00Z',
      important: true,
      pinned: false
    }
  ],
  regras: [
    {
      id: 1,
      version: '2.4.1',
      title: 'Atualização das Regras Gerais',
      content: '• Respeito mútuo é obrigatório.\n• Proibido spam e flood em qualquer canal.\n• Conteúdo NSFW apenas em canais designados.\n• Divulgação de outros servidores somente com autorização.\n• Contas alternativas (alts) devem ser reportadas à staff.',
      changes: ['Adicionado regra sobre alts', 'Clarificado política de NSFW'],
      createdAt: '2026-10-28T12:00:00Z',
      author: 'AdminMaster'
    },
    {
      id: 2,
      version: '2.4.0',
      title: 'Nova seção de economia',
      content: 'Foi adicionada a seção 7: Economia do servidor. Coins obtidos em eventos não podem ser transferidos para contas novas sem 7 dias de idade.',
      changes: ['Nova seção 7'],
      createdAt: '2026-09-15T18:00:00Z',
      author: 'AdminMaster'
    }
  ],
  bots: [
    {
      id: 1,
      botName: 'GuardianBot',
      version: '3.2.0',
      title: 'GuardianBot v3.2.0 - Sistema de tickets melhorado',
      content: '• Novo sistema de tickets com categorias\n• Logs mais detalhados\n• Suporte a anexos em tickets\n• Correção de bug no auto-mod',
      changelog: ['Tickets com categorias', 'Logs aprimorados', 'Bugfix auto-mod'],
      createdAt: '2026-11-03T20:00:00Z',
      author: 'DevTeam'
    },
    {
      id: 2,
      botName: 'EconomyBot',
      version: '1.8.5',
      title: 'EconomyBot - Ajuste de taxas',
      content: 'Ajustamos as taxas de transferência e adicionamos novo item na loja: "Boost de XP x2 (1h)".',
      changelog: ['Novas taxas', 'Item de loja'],
      createdAt: '2026-10-20T14:00:00Z',
      author: 'DevTeam'
    }
  ],
  cartas: [
    {
      id: 1,
      to: 'all', // or specific user id
      toName: 'Todos os membros',
      subject: 'Obrigado por fazer parte da comunidade!',
      content: 'Queremos agradecer a todos que estão ativos no servidor. Vocês são o motivo de continuarmos melhorando. Qualquer sugestão, use o canal #sugestões.',
      from: 'AdminMaster',
      fromId: '1001',
      createdAt: '2026-11-02T11:00:00Z',
      read: false,
      type: 'official'
    },
    {
      id: 2,
      to: '2002',
      toName: 'MembroComum',
      subject: 'Seu report foi analisado',
      content: 'Olá! Analisamos o report que você enviou sobre o usuário XYZ. Tomamos as medidas necessárias. Obrigado por ajudar a manter a comunidade segura.',
      from: 'ModeradorX',
      fromId: '1003',
      createdAt: '2026-11-05T16:45:00Z',
      read: false,
      type: 'private'
    }
  ],
  noticias: [
    {
      id: 1,
      title: 'Parceria com outro servidor',
      content: 'Fechamos uma parceria oficial com o servidor XYZ. Membros de ambos os lados terão acesso a eventos exclusivos.',
      image: null,
      createdAt: '2026-11-01T08:00:00Z',
      author: 'Staff'
    },
    {
      id: 2,
      title: 'Novo cargo: Booster+',
      content: 'Boosters do servidor agora recebem o cargo Booster+ com perks adicionais no site e no Discord.',
      image: null,
      createdAt: '2026-10-25T12:00:00Z',
      author: 'Staff'
    }
  ]
};

function load(key) {
  const stored = localStorage.getItem(STORAGE_KEYS[key]);
  if (stored) {
    try { return JSON.parse(stored); } catch { /* fallthrough */ }
  }
  // Seed if empty
  const data = SEED[key] || [];
  localStorage.setItem(STORAGE_KEYS[key], JSON.stringify(data));
  return data;
}

function save(key, data) {
  localStorage.setItem(STORAGE_KEYS[key], JSON.stringify(data));
}

function addItem(key, item) {
  const data = load(key);
  item.id = Date.now();
  item.createdAt = new Date().toISOString();
  data.unshift(item);
  save(key, data);
  return item;
}

function updateItem(key, id, updates) {
  const data = load(key);
  const idx = data.findIndex(i => i.id === id);
  if (idx !== -1) {
    data[idx] = { ...data[idx], ...updates };
    save(key, data);
    return data[idx];
  }
  return null;
}

function deleteItem(key, id) {
  let data = load(key);
  data = data.filter(i => i.id !== id);
  save(key, data);
}

// Permissions mock
function getPermissions() {
  return JSON.parse(localStorage.getItem(STORAGE_KEYS.permissoes) || JSON.stringify({
    admins: ['1001'],
    moderators: ['1001', '1003'],
    canCreateAnuncios: ['1001', '1003'],
    canSendCartas: ['1001']
  }));
}

function savePermissions(perms) {
  localStorage.setItem(STORAGE_KEYS.permissoes, JSON.stringify(perms));
}

window.WAData = {
  load,
  save,
  addItem,
  updateItem,
  deleteItem,
  getPermissions,
  savePermissions,
  STORAGE_KEYS
};
