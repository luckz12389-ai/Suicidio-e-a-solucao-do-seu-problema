// WEB ADMINS - Dashboard Logic

document.addEventListener('DOMContentLoaded', async () => {
  // Processa token vindo do callback OAuth (#token=...)
  WAAuth.handleAuthCallback();

  // Se não estiver logado, volta pro login
  if (!WAAuth.isLoggedIn()) {
    window.location.href = 'index.html';
    return;
  }

  // Valida o token com o backend (opcional, mas recomendado)
  await WAAuth.validateSession();

  const user = WAAuth.getUser();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }

  // Registra o login
  WAAuth.logLogin(user);
  WAAuth.logActivity('login', `${user.username || user.global_name} entrou no painel`);

  // Populate user info
  document.getElementById('userAvatar').src = user.avatar || 'https://cdn.discordapp.com/embed/avatars/0.png';
  const displayName = user.global_name || user.username || 'Usuário';
  document.getElementById('userName').textContent = displayName;
  document.getElementById('userRole').textContent = user.isAdmin ? 'Administrador' : 'Membro';

  // Show admin nav if permitted
  if (WAAuth.isAdmin()) {
    document.getElementById('adminNav').classList.remove('hidden');
  }

  // Mobile menu
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const menuBtn = document.getElementById('menuBtn');

  menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
  });
  overlay.addEventListener('click', () => {
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
  });

  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    WAAuth.logActivity('logout', `${user.username} saiu do painel`);
    WAAuth.logout();
  });

  // Navigation
  const links = document.querySelectorAll('.sidebar-link');
  const content = document.getElementById('content');
  const pageTitle = document.getElementById('pageTitle');

  const titles = {
    'anuncios': 'Anúncios',
    'regras': 'Regras & Updates',
    'bots': 'Notas de Bots',
    'cartas': 'Cartas & Mensagens',
    'noticias': 'Notícias',
    'admin-logins': 'Logins & Acessos',
    'admin-atividades': 'Atividades do Site',
    'admin-anuncios': 'Criar Anúncio',
    'admin-cartas': 'Enviar Carta',
    'admin-membros': 'Gerenciar Permissões'
  };

  function setActive(section) {
    links.forEach(l => l.classList.remove('active'));
    const activeLink = document.querySelector(`[data-section="${section}"]`);
    if (activeLink) activeLink.classList.add('active');
    pageTitle.textContent = titles[section] || 'Dashboard';
    // Close mobile menu
    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');
  }

  links.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const section = link.dataset.section;
      setActive(section);
      renderSection(section);
    });
  });

  // Initial render
  renderSection('anuncios');

  // Refresh button
  document.getElementById('refreshBtn').addEventListener('click', () => {
    const active = document.querySelector('.sidebar-link.active');
    if (active) renderSection(active.dataset.section);
  });

  // ========== RENDERERS ==========

  function renderSection(section) {
    content.innerHTML = '';
    switch (section) {
      case 'anuncios': renderAnuncios(); break;
      case 'regras': renderRegras(); break;
      case 'bots': renderBots(); break;
      case 'cartas': renderCartas(); break;
      case 'noticias': renderNoticias(); break;
      case 'admin-logins': renderAdminLogins(); break;
      case 'admin-atividades': renderAdminAtividades(); break;
      case 'admin-anuncios': renderAdminCriarAnuncio(); break;
      case 'admin-cartas': renderAdminEnviarCarta(); break;
      case 'admin-membros': renderAdminMembros(); break;
      default: content.innerHTML = '<p class="text-gray-500">Seção não encontrada.</p>';
    }
  }

  function card(html) {
    return `<div class="glass glass-hover rounded-xl p-5 mb-4 transition-all">${html}</div>`;
  }

  function formatDate(iso) {
    const d = new Date(iso);
    return d.toLocaleString('pt-BR', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  }

  function timeAgo(iso) {
    const diff = (Date.now() - new Date(iso)) / 1000;
    if (diff < 60) return 'agora';
    if (diff < 3600) return Math.floor(diff / 60) + ' min atrás';
    if (diff < 86400) return Math.floor(diff / 3600) + ' h atrás';
    if (diff < 604800) return Math.floor(diff / 86400) + ' dias atrás';
    return formatDate(iso);
  }

  // --- ANÚNCIOS ---
  function renderAnuncios() {
    const data = WAData.load('anuncios');
    let html = `
      <div class="mb-6">
        <p class="text-gray-400 text-sm">Fique por dentro das últimas comunicações oficiais do servidor.</p>
      </div>
    `;
    if (data.length === 0) {
      html += emptyState('Nenhum anúncio ainda.', 'fa-bullhorn');
    } else {
      data.forEach(a => {
        html += card(`
          <div class="flex items-start justify-between gap-4">
            <div class="flex-1">
              <div class="flex items-center gap-2 mb-2 flex-wrap">
                ${a.pinned ? '<span class="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full"><i class="fas fa-thumbtack mr-1"></i>Fixado</span>' : ''}
                ${a.important ? '<span class="text-[10px] bg-red-500/20 text-red-300 px-2 py-0.5 rounded-full"><i class="fas fa-exclamation-circle mr-1"></i>Importante</span>' : ''}
                <span class="text-xs text-gray-500">${timeAgo(a.createdAt)}</span>
              </div>
              <h3 class="font-semibold text-lg text-white mb-2">${escapeHtml(a.title)}</h3>
              <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-line">${escapeHtml(a.content)}</p>
              <div class="mt-3 flex items-center gap-2 text-xs text-gray-500">
                <i class="fas fa-user"></i> ${escapeHtml(a.author)}
              </div>
            </div>
          </div>
        `);
      });
    }
    content.innerHTML = html;
  }

  // --- REGRAS ---
  function renderRegras() {
    const data = WAData.load('regras');
    let html = `<div class="mb-6"><p class="text-gray-400 text-sm">Atualizações e mudanças nas regras do servidor.</p></div>`;
    if (data.length === 0) {
      html += emptyState('Nenhuma atualização de regras.', 'fa-gavel');
    } else {
      data.forEach(r => {
        html += card(`
          <div class="flex items-center gap-2 mb-2">
            <span class="text-xs font-mono bg-white/10 px-2 py-0.5 rounded">v${r.version}</span>
            <span class="text-xs text-gray-500">${timeAgo(r.createdAt)}</span>
          </div>
          <h3 class="font-semibold text-lg text-white mb-2">${escapeHtml(r.title)}</h3>
          <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-line mb-3">${escapeHtml(r.content)}</p>
          ${r.changes && r.changes.length ? `
            <div class="mt-3 pt-3 border-t border-white/10">
              <p class="text-xs text-gray-500 mb-1">Mudanças:</p>
              <ul class="text-xs text-gray-400 list-disc list-inside">
                ${r.changes.map(c => `<li>${escapeHtml(c)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
          <div class="mt-2 text-xs text-gray-500"><i class="fas fa-user mr-1"></i>${escapeHtml(r.author)}</div>
        `);
      });
    }
    content.innerHTML = html;
  }

  // --- BOTS ---
  function renderBots() {
    const data = WAData.load('bots');
    let html = `<div class="mb-6"><p class="text-gray-400 text-sm">Notas de atualização dos bots oficiais do servidor.</p></div>`;
    if (data.length === 0) {
      html += emptyState('Nenhuma nota de bot ainda.', 'fa-robot');
    } else {
      data.forEach(b => {
        html += card(`
          <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center">
              <i class="fas fa-robot text-indigo-300"></i>
            </div>
            <div>
              <h3 class="font-semibold text-white">${escapeHtml(b.botName)}</h3>
              <span class="text-xs font-mono text-gray-400">v${b.version}</span>
            </div>
            <span class="ml-auto text-xs text-gray-500">${timeAgo(b.createdAt)}</span>
          </div>
          <h4 class="font-medium text-gray-200 mb-2">${escapeHtml(b.title)}</h4>
          <p class="text-gray-300 text-sm leading-relaxed whitespace-pre-line mb-3">${escapeHtml(b.content)}</p>
          ${b.changelog ? `
            <div class="flex flex-wrap gap-1.5">
              ${b.changelog.map(c => `<span class="text-[10px] bg-white/5 border border-white/10 px-2 py-0.5 rounded-full text-gray-400">${escapeHtml(c)}</span>`).join('')}
            </div>
          ` : ''}
        `);
      });
    }
    content.innerHTML = html;
  }

  // --- CARTAS ---
  function renderCartas() {
    const all = WAData.load('cartas');
    const user = WAAuth.getUser();
    // Show cartas for this user or "all"
    const data = all.filter(c => c.to === 'all' || c.to === user.id || c.toName === user.username);
    
    let html = `
      <div class="mb-6 flex items-center justify-between">
        <p class="text-gray-400 text-sm">Mensagens oficiais e cartas privadas enviadas pela staff.</p>
      </div>
    `;
    if (data.length === 0) {
      html += emptyState('Sua caixa de cartas está vazia.', 'fa-envelope');
    } else {
      data.forEach(c => {
        const isUnread = !c.read;
        html += card(`
          <div class="flex items-start gap-4 cursor-pointer" onclick="markCartaRead(${c.id})">
            <div class="w-10 h-10 rounded-full ${c.type === 'private' ? 'bg-purple-500/20' : 'bg-blue-500/20'} flex items-center justify-center flex-shrink-0">
              <i class="fas ${c.type === 'private' ? 'fa-lock' : 'fa-bullhorn'} ${c.type === 'private' ? 'text-purple-300' : 'text-blue-300'}"></i>
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2 mb-1 flex-wrap">
                ${isUnread ? '<span class="w-2 h-2 rounded-full bg-blue-400"></span>' : ''}
                <h3 class="font-semibold text-white truncate">${escapeHtml(c.subject)}</h3>
                <span class="text-[10px] ${c.type === 'private' ? 'bg-purple-500/20 text-purple-300' : 'bg-blue-500/20 text-blue-300'} px-2 py-0.5 rounded-full">${c.type === 'private' ? 'Privada' : 'Oficial'}</span>
              </div>
              <p class="text-gray-400 text-sm line-clamp-2">${escapeHtml(c.content)}</p>
              <div class="mt-2 flex items-center gap-3 text-xs text-gray-500">
                <span><i class="fas fa-user mr-1"></i>${escapeHtml(c.from)}</span>
                <span>${timeAgo(c.createdAt)}</span>
              </div>
            </div>
          </div>
        `);
      });
    }
    content.innerHTML = html;
  }

  window.markCartaRead = function(id) {
    WAData.updateItem('cartas', id, { read: true });
    // Update badge
    updateBadges();
    renderCartas();
  };

  // --- NOTÍCIAS ---
  function renderNoticias() {
    const data = WAData.load('noticias');
    let html = `<div class="mb-6"><p class="text-gray-400 text-sm">Notícias e novidades da comunidade.</p></div>`;
    if (data.length === 0) {
      html += emptyState('Nenhuma notícia no momento.', 'fa-newspaper');
    } else {
      data.forEach(n => {
        html += card(`
          <h3 class="font-semibold text-lg text-white mb-2">${escapeHtml(n.title)}</h3>
          <p class="text-gray-300 text-sm leading-relaxed">${escapeHtml(n.content)}</p>
          <div class="mt-3 flex items-center gap-3 text-xs text-gray-500">
            <span><i class="fas fa-user mr-1"></i>${escapeHtml(n.author)}</span>
            <span>${timeAgo(n.createdAt)}</span>
          </div>
        `);
      });
    }
    content.innerHTML = html;
  }

  // ========== ADMIN SECTIONS ==========

  function renderAdminLogins() {
    if (!WAAuth.isAdmin()) return accessDenied();
    const logins = WAAuth.getLogins();
    let html = `
      <div class="mb-6">
        <p class="text-gray-400 text-sm">Histórico de acessos ao painel administrativo.</p>
      </div>
      <div class="glass rounded-xl overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead class="bg-white/5 text-gray-400 text-xs uppercase">
              <tr>
                <th class="px-4 py-3 text-left">Usuário</th>
                <th class="px-4 py-3 text-left">IP</th>
                <th class="px-4 py-3 text-left">Data</th>
                <th class="px-4 py-3 text-left">Tipo</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5">
    `;
    if (logins.length === 0) {
      html += `<tr><td colspan="4" class="px-4 py-8 text-center text-gray-500">Nenhum login registrado ainda.</td></tr>`;
    } else {
      logins.forEach(l => {
        html += `
          <tr class="hover:bg-white/5">
            <td class="px-4 py-3">
              <div class="flex items-center gap-2">
                <img src="${l.avatar}" class="w-7 h-7 rounded-full" alt="">
                <span class="font-medium">${escapeHtml(l.username)}</span>
              </div>
            </td>
            <td class="px-4 py-3 font-mono text-xs text-gray-400">${l.ip}</td>
            <td class="px-4 py-3 text-gray-400">${formatDate(l.timestamp)}</td>
            <td class="px-4 py-3">
              <span class="text-[10px] px-2 py-0.5 rounded-full ${l.isAdmin ? 'bg-amber-500/20 text-amber-300' : 'bg-gray-500/20 text-gray-300'}">
                ${l.isAdmin ? 'Admin' : 'Membro'}
              </span>
            </td>
          </tr>
        `;
      });
    }
    html += `</tbody></table></div></div>`;
    content.innerHTML = html;
  }

  function renderAdminAtividades() {
    if (!WAAuth.isAdmin()) return accessDenied();
    const activities = WAAuth.getActivities();
    let html = `
      <div class="mb-6">
        <p class="text-gray-400 text-sm">Registro de atividades recentes no site.</p>
      </div>
    `;
    if (activities.length === 0) {
      html += emptyState('Nenhuma atividade registrada.', 'fa-chart-line');
    } else {
      activities.forEach(a => {
        const icon = {
          login: 'fa-sign-in-alt text-green-400',
          logout: 'fa-sign-out-alt text-red-400',
          anuncio: 'fa-bullhorn text-blue-400',
          carta: 'fa-paper-plane text-purple-400',
          default: 'fa-circle text-gray-400'
        }[a.type] || 'fa-circle text-gray-400';
        
        html += card(`
          <div class="flex items-center gap-4">
            <div class="w-9 h-9 rounded-full bg-white/5 flex items-center justify-center">
              <i class="fas ${icon}"></i>
            </div>
            <div class="flex-1">
              <p class="text-sm text-gray-200">${escapeHtml(a.message)}</p>
              <p class="text-xs text-gray-500 mt-0.5">${escapeHtml(a.user)} • ${timeAgo(a.timestamp)}</p>
            </div>
          </div>
        `);
      });
    }
    content.innerHTML = html;
  }

  function renderAdminCriarAnuncio() {
    if (!WAAuth.isAdmin()) return accessDenied();
    content.innerHTML = `
      <div class="max-w-2xl">
        <div class="mb-6">
          <p class="text-gray-400 text-sm">Crie um novo anúncio que será visível para todos os membros logados.</p>
        </div>
        <form id="formAnuncio" class="glass rounded-xl p-6 space-y-5">
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Título</label>
            <input type="text" name="title" required maxlength="120"
              class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-white/30 transition"
              placeholder="Ex: Evento especial de sábado">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Conteúdo</label>
            <textarea name="content" required rows="6" maxlength="2000"
              class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-white/30 transition resize-y"
              placeholder="Escreva o anúncio completo..."></textarea>
          </div>
          <div class="flex items-center gap-6">
            <label class="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" name="important" class="rounded border-white/20 bg-black/40 text-amber-500 focus:ring-0">
              <span class="text-sm text-gray-300">Marcar como importante</span>
            </label>
            <label class="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" name="pinned" class="rounded border-white/20 bg-black/40 text-amber-500 focus:ring-0">
              <span class="text-sm text-gray-300">Fixar no topo</span>
            </label>
          </div>
          <div class="pt-2">
            <button type="submit" class="bg-white text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-gray-200 transition flex items-center gap-2">
              <i class="fas fa-paper-plane"></i> Publicar Anúncio
            </button>
          </div>
        </form>
      </div>
    `;

    document.getElementById('formAnuncio').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const user = WAAuth.getUser();
      const item = WAData.addItem('anuncios', {
        title: fd.get('title'),
        content: fd.get('content'),
        author: user.username,
        authorId: user.id,
        important: fd.get('important') === 'on',
        pinned: fd.get('pinned') === 'on'
      });
      WAAuth.logActivity('anuncio', `Novo anúncio publicado: "${item.title}"`);
      alert('Anúncio publicado com sucesso!');
      e.target.reset();
    });
  }

  function renderAdminEnviarCarta() {
    if (!WAAuth.isAdmin()) return accessDenied();
    content.innerHTML = `
      <div class="max-w-2xl">
        <div class="mb-6">
          <p class="text-gray-400 text-sm">Envie uma carta oficial ou mensagem privada para membros.</p>
        </div>
        <form id="formCarta" class="glass rounded-xl p-6 space-y-5">
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Destinatário</label>
            <select name="to" class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-white/30">
              <option value="all">Todos os membros</option>
              <option value="2002">MembroComum (demo)</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Assunto</label>
            <input type="text" name="subject" required maxlength="100"
              class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-white/30"
              placeholder="Assunto da carta">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Mensagem</label>
            <textarea name="content" required rows="6" maxlength="2000"
              class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-white/30 resize-y"
              placeholder="Escreva a mensagem..."></textarea>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-300 mb-1.5">Tipo</label>
            <div class="flex gap-4">
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="type" value="official" checked class="text-blue-500 focus:ring-0">
                <span class="text-sm">Oficial (todos veem)</span>
              </label>
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="type" value="private" class="text-purple-500 focus:ring-0">
                <span class="text-sm">Privada</span>
              </label>
            </div>
          </div>
          <div class="pt-2">
            <button type="submit" class="bg-white text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-gray-200 transition flex items-center gap-2">
              <i class="fas fa-paper-plane"></i> Enviar Carta
            </button>
          </div>
        </form>
      </div>
    `;

    document.getElementById('formCarta').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const user = WAAuth.getUser();
      const to = fd.get('to');
      const item = WAData.addItem('cartas', {
        to: to,
        toName: to === 'all' ? 'Todos os membros' : 'MembroComum',
        subject: fd.get('subject'),
        content: fd.get('content'),
        from: user.username,
        fromId: user.id,
        read: false,
        type: fd.get('type')
      });
      WAAuth.logActivity('carta', `Carta enviada: "${item.subject}"`);
      alert('Carta enviada com sucesso!');
      e.target.reset();
    });
  }

  function renderAdminMembros() {
    if (!WAAuth.isAdmin()) return accessDenied();
    const user = WAAuth.getUser();
    content.innerHTML = `
      <div class="mb-6">
        <p class="text-gray-400 text-sm">Informações da sua conta e como as permissões funcionam.</p>
      </div>
      <div class="grid gap-4 max-w-2xl">
        <div class="glass rounded-xl p-5">
          <h3 class="font-semibold mb-3 flex items-center gap-2">
            <i class="fas fa-user text-gray-300"></i> Seu usuário
          </h3>
          <div class="flex items-center gap-4">
            <img src="${user.avatar}" class="w-14 h-14 rounded-full border border-white/20" alt="">
            <div>
              <p class="font-medium text-white">${user.global_name || user.username}</p>
              <p class="text-xs text-gray-500 font-mono">ID: ${user.id}</p>
              <p class="text-xs mt-1">
                <span class="px-2 py-0.5 rounded-full ${user.isAdmin ? 'bg-amber-500/20 text-amber-300' : 'bg-gray-500/20 text-gray-300'}">
                  ${user.isAdmin ? 'Administrador' : 'Membro'}
                </span>
              </p>
            </div>
          </div>
        </div>

        <div class="glass rounded-xl p-5">
          <h3 class="font-semibold mb-3 flex items-center gap-2">
            <i class="fas fa-id-badge text-blue-400"></i> Cargos recebidos do Discord
          </h3>
          <div class="flex flex-wrap gap-2">
            ${(user.roles && user.roles.length)
              ? user.roles.map(r => `<span class="bg-white/10 text-gray-300 text-xs px-3 py-1 rounded-full font-mono">${r}</span>`).join('')
              : '<span class="text-sm text-gray-500">Nenhum cargo retornado (verifique se o bot tem Server Members Intent e está no servidor)</span>'}
          </div>
        </div>

        <div class="glass rounded-xl p-5">
          <h3 class="font-semibold mb-3 flex items-center gap-2">
            <i class="fas fa-info-circle text-blue-400"></i> Como a permissão de Admin funciona
          </h3>
          <p class="text-sm text-gray-400 leading-relaxed">
            No callback do login o backend busca seus cargos no servidor (via Bot Token) e verifica se algum deles está na lista 
            <code class="text-xs bg-white/10 px-1.5 py-0.5 rounded">DISCORD_ADMIN_ROLE_IDS</code> 
            configurada nas variáveis de ambiente do Netlify.<br><br>
            Se tiver, você recebe <strong class="text-amber-300">isAdmin = true</strong> e a Área Secreta aparece no menu.
          </p>
        </div>
      </div>
    `;
  }

  // Helpers
  function emptyState(msg, icon) {
    return `
      <div class="flex flex-col items-center justify-center py-20 text-gray-500">
        <i class="fas ${icon} text-4xl mb-4 opacity-40"></i>
        <p class="text-sm">${msg}</p>
      </div>
    `;
  }

  function accessDenied() {
    content.innerHTML = `
      <div class="flex flex-col items-center justify-center py-20">
        <i class="fas fa-lock text-5xl text-red-400/50 mb-4"></i>
        <h3 class="text-xl font-semibold text-white mb-2">Acesso Negado</h3>
        <p class="text-gray-400 text-sm">Você não tem permissão para visualizar esta área.</p>
      </div>
    `;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function updateBadges() {
    // Simple badge update for cartas
    const all = WAData.load('cartas');
    const user = WAAuth.getUser();
    const unread = all.filter(c => !c.read && (c.to === 'all' || c.to === user.id)).length;
    const badge = document.getElementById('badgeCartas');
    if (badge) {
      if (unread > 0) {
        badge.textContent = unread;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }
  }

  updateBadges();
});
