// Inicia o fluxo OAuth2 do Discord
// GET /.netlify/functions/auth-login

const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const SITE_URL = process.env.URL || process.env.DEPLOY_PRIME_URL || 'http://localhost:8888';
const REDIRECT_URI = `${SITE_URL}/.netlify/functions/auth-callback`;

exports.handler = async () => {
  if (!CLIENT_ID) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'DISCORD_CLIENT_ID não configurado. Veja o README para configurar as variáveis de ambiente no Netlify.'
      })
    };
  }

  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'identify guilds guilds.members.read',
    prompt: 'consent'
  });

  return {
    statusCode: 302,
    headers: {
      Location: `https://discord.com/api/oauth2/authorize?${params.toString()}`,
      'Cache-Control': 'no-cache'
    }
  };
};
