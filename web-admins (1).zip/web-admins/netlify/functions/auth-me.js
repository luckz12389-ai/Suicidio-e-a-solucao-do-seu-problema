// Valida o JWT e retorna os dados do usuário
// GET /.netlify/functions/auth-me
// Header: Authorization: Bearer <jwt>

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production-please';

function base64urlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return Buffer.from(str, 'base64').toString();
}

function verifyJWT(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  const [headerB64, bodyB64, signature] = parts;
  const data = `${headerB64}.${bodyB64}`;

  const crypto = require('crypto');
  const expected = crypto
    .createHmac('sha256', secret)
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  if (signature !== expected) return null;

  try {
    const payload = JSON.parse(base64urlDecode(bodyB64));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

exports.handler = async (event) => {
  const authHeader = event.headers.authorization || event.headers.Authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'No token provided' })
    };
  }

  const payload = verifyJWT(token, JWT_SECRET);
  if (!payload) {
    return {
      statusCode: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Invalid or expired token' })
    };
  }

  // Remove sensitive fields before returning
  const { accessToken, ...safeUser } = payload;

  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store'
    },
    body: JSON.stringify(safeUser)
  };
};
