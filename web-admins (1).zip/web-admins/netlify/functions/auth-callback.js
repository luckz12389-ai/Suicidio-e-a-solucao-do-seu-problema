// Callback do Discord OAuth2
// GET /.netlify/functions/auth-callback?code=...

const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
const GUILD_ID = process.env.DISCORD_GUILD_ID;
const ADMIN_ROLE_IDS = (process.env.DISCORD_ADMIN_ROLE_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production-please';

const SITE_URL = process.env.URL || process.env.DEPLOY_PRIME_URL || 'http://localhost:8888';
const REDIRECT_URI = `${SITE_URL}/.netlify/functions/auth-callback`;

// Simple JWT implementation (no external deps)
function base64url(input) {
  return Buffer.from(input).toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function signJWT(payload, secret, expiresInSec = 60 * 60 * 24 * 7) { // 7 days
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const body = { ...payload, iat: now, exp: now + expiresInSec };

  const headerB64 = base64url(JSON.stringify(header));
  const bodyB64 = base64url(JSON.stringify(body));
  const data = `${headerB64}.${bodyB64}`;

  const crypto = require('crypto');
  const signature = crypto
    .createHmac('sha256', secret)
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  return `${data}.${signature}`;
}

async function exchangeCode(code) {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    grant_type: 'authorization_code',
    code,
    redirect_uri: REDIRECT_URI
  });

  const res = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString()
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Token exchange failed: ${res.status} ${text}`);
  }
  return res.json();
}

async function fetchUser(accessToken) {
  const res = await fetch('https://discord.com/api/users/@me', {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) throw new Error('Failed to fetch user');
  return res.json();
}

async function fetchGuildMember(userId) {
  if (!BOT_TOKEN || !GUILD_ID) return null;

  const res = await fetch(`https://discord.com/api/guilds/${GUILD_ID}/members/${userId}`, {
    headers: { Authorization: `Bot ${BOT_TOKEN}` }
  });

  if (res.status === 404) return null; // not in guild
  if (!res.ok) {
    console.error('Failed to fetch guild member', res.status, await res.text());
    return null;
  }
  return res.json();
}

exports.handler = async (event) => {
  const code = event.queryStringParameters?.code;
  const error = event.queryStringParameters?.error;

  if (error) {
    return {
      statusCode: 302,
      headers: { Location: `${SITE_URL}/index.html?error=${encodeURIComponent(error)}` }
    };
  }

  if (!code) {
    return {
      statusCode: 400,
      body: 'Missing authorization code'
    };
  }

  if (!CLIENT_ID || !CLIENT_SECRET) {
    return {
      statusCode: 500,
      body: 'Discord credentials not configured'
    };
  }

  try {
    const tokenData = await exchangeCode(code);
    const user = await fetchUser(tokenData.access_token);
    const member = await fetchGuildMember(user.id);

    // Determine if admin
    let isAdmin = false;
    let roles = [];

    if (member && member.roles) {
      roles = member.roles;
      if (ADMIN_ROLE_IDS.length > 0) {
        isAdmin = ADMIN_ROLE_IDS.some(roleId => roles.includes(roleId));
      }
    }

    // Optional: only allow people who are in the guild
    // if (!member) { ... redirect with error }

    const payload = {
      id: user.id,
      username: user.username,
      global_name: user.global_name || user.username,
      discriminator: user.discriminator,
      avatar: user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
        : `https://cdn.discordapp.com/embed/avatars/${(parseInt(user.discriminator || '0', 10) % 5)}.png`,
      roles,
      isAdmin,
      accessToken: tokenData.access_token // careful: only if you need it later
    };

    const jwt = signJWT(payload, JWT_SECRET);

    // Redirect to dashboard with token in hash (frontend will pick it up)
    // Using hash so the token is not sent to the server on subsequent page loads
    return {
      statusCode: 302,
      headers: {
        Location: `${SITE_URL}/dashboard.html#token=${jwt}`,
        'Cache-Control': 'no-cache'
      }
    };
  } catch (err) {
    console.error('Auth callback error:', err);
    return {
      statusCode: 302,
      headers: {
        Location: `${SITE_URL}/index.html?error=${encodeURIComponent(err.message)}`
      }
    };
  }
};
